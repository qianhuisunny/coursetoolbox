<?php

namespace Wpai\AddonAPI;

class PMXI_Addon_Toggle_Field extends PMXI_Addon_Switcher_Field {
}
