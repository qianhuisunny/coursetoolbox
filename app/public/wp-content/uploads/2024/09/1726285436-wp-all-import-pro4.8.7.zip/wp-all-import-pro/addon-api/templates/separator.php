<div class="pmxi-addon-separator">
    <div class="pmxi-addon-separator-content">
        <h3 class="pmxi-addon-separator__title"><?php echo $field['label']; ?></h3>