<?php
/**
 * @author Olexandr Zanichkovsky <olexandr.zanichkovsky@zophiatech.com>
 * @package AST
 */

require_once dirname(__FILE__) . '/XmlImportAstXpathClause.php';

/**
 * Represents a FOREACH clause
 */
class XmlImportAstForeach extends XmlImportAstXPathClause
{
}
