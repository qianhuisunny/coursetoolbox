<?php

namespace Wpai\AddonAPI;

class PMXI_Addon_Radio_Field extends PMXI_Addon_Switcher_Field {
}
